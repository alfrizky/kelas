<template>
    <h1>DETAIL</h1>
  </template>